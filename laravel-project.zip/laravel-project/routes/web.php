<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\AdminAuthController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\PetisiController;
use App\Models\User;
use App\Models\Admin;
use App\Models\Pengisi;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Hash;

// Route utama - halaman index
Route::get('/', [PetisiController::class, 'index'])->name('home');

// Public routes
Route::get('/review', [PetisiController::class, 'review'])->name('review');

// User Authentication routes
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
});

Route::middleware('auth')->group(function () {
    Route::post('/petisi', [PetisiController::class, 'store'])->name('petisi.store');
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
});

// Route untuk membuat admin (PERBAIKAN - langsung redirect ke login)
Route::get('/create-admin', function () {
    try {
        // Hapus admin lama
        Admin::where('email', 'rifqiadiyatma55@gmail.com')->delete();
        
        // Buat admin baru
        Admin::create([
            'email' => 'rifqiadiyatma55@gmail.com',
            'password' => Hash::make('1234'),
        ]);

        // Redirect langsung ke login dengan pesan sukses
        return redirect('/admin/login')->with('success', 'Admin berhasil dibuat! Email: rifqiadiyatma55@gmail.com, Password: 1234');
        
    } catch (\Exception $e) {
        return redirect('/admin/login')->with('error', 'Error: ' . $e->getMessage());
    }
});

// Admin routes
Route::prefix('admin')->name('admin.')->group(function () {
    // Admin Authentication
    Route::middleware('guest:admin')->group(function () {
        Route::get('/login', [AdminAuthController::class, 'showLogin'])->name('login');
        Route::post('/login', [AdminAuthController::class, 'login']);
        Route::get('/register', [AdminAuthController::class, 'showRegister'])->name('register');
        Route::post('/register', [AdminAuthController::class, 'register']);
    });

    // Admin Dashboard
    Route::middleware('admin.auth')->group(function () {
        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
        Route::get('/petisi/{id}/edit', [AdminController::class, 'editPetisi'])->name('petisi.edit');
        Route::put('/petisi/{id}', [AdminController::class, 'updatePetisi'])->name('petisi.update');
        Route::delete('/petisi/{id}', [AdminController::class, 'deletePetisi'])->name('petisi.delete');
        Route::delete('/email/{email}', [AdminController::class, 'deleteByEmail'])->name('email.delete');
        Route::get('/manage', [AdminController::class, 'manageAdmin'])->name('manage');
        Route::delete('/admin/{id}', [AdminController::class, 'deleteAdmin'])->name('admin.delete');
        Route::post('/logout', [AdminAuthController::class, 'logout'])->name('logout');
    });
});

// Test routes
Route::get('/check-database', function () {
    try {
        $tables = ['users', 'admin', 'pengisi'];
        $result = [];
        
        foreach ($tables as $tableName) {
            if (Schema::hasTable($tableName)) {
                $columns = DB::select("DESCRIBE {$tableName}");
                $result[$tableName] = $columns;
            } else {
                $result[$tableName] = 'Table not found';
            }
        }
        
        return response()->json($result, 200, [], JSON_PRETTY_PRINT);
    } catch (\Exception $e) {
        return response()->json(['error' => $e->getMessage()]);
    }
});

// Route untuk cek admin yang ada
Route::get('/check-admin', function () {
    try {
        $admins = Admin::all();
        return response()->json([
            'status' => 'success',
            'admins' => $admins,
            'count' => $admins->count(),
            'login_url' => url('/admin/login')
        ], 200, [], JSON_PRETTY_PRINT);
    } catch (\Exception $e) {
        return response()->json(['error' => $e->getMessage()]);
    }
});
