<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Petisi Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">

<!-- Header -->
<header class="bg-red-600 text-white py-4 fixed w-full z-10 top-0 left-0">
    <div class="max-w-6xl mx-auto flex justify-between items-center px-4">
        <div class="text-lg font-semibold">
            <a href="{{ route('home') }}" class="text-white">Petisi Mahasiswa</a>
        </div>
    </div>
</header>

<!-- Form Login -->
<section class="py-16 px-6 max-w-md mx-auto bg-white rounded-lg shadow-lg mt-20">
    <h2 class="text-2xl font-bold mb-6 text-center">Masuk ke Petisi Mahasiswa</h2>

    @if($errors->any())
        <div class="p-4 bg-red-100 text-red-800 rounded mb-4">
            @foreach($errors->all() as $error)
                {{ $error }}
            @endforeach
        </div>
    @endif

    <form method="POST" action="{{ route('login') }}" class="space-y-4">
        @csrf
        <div>
            <label for="email" class="block text-sm font-semibold">Email</label>
            <input type="email" id="email" name="email" value="{{ old('email') }}" class="w-full px-4 py-2 border border-gray-300 rounded" placeholder="Masukkan email" required>
        </div>
        <div>
            <label for="password" class="block text-sm font-semibold">Password</label>
            <input type="password" id="password" name="password" class="w-full px-4 py-2 border border-gray-300 rounded" placeholder="Masukkan password" required>
        </div>
        <button type="submit" class="bg-red-600 text-white font-semibold py-2 px-6 rounded-full hover:bg-red-700 transition w-full">Masuk</button>
    </form>

    <div class="mt-4 text-center">
        <p class="text-sm">Belum punya akun? <a href="{{ route('register') }}" class="text-red-600 font-semibold">Daftar di sini</a></p>
    </div>
</section>

</body>
</html>
