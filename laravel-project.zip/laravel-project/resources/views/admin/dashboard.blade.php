<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Petisi Mahasiswa</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            background: #f4f6f8;
            color: #333;
        }
        .container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 240px;
            background-color: #2C3E50;
            color: #fff;
            padding: 20px;
            display: flex;
            flex-direction: column;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar a {
            text-decoration: none;
            color: #fff;
            padding: 12px;
            display: block;
            border-radius: 5px;
            margin-bottom: 10px;
            background-color: #34495E;
            transition: background-color 0.3s;
        }
        .sidebar a:hover {
            background-color: #1ABC9C;
        }
        .sidebar .logout-btn {
            margin-top: auto;
            background-color: #E74C3C;
            border: none;
            color: #fff;
            padding: 12px;
            display: block;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            width: 100%;
        }

        .main-content {
            flex: 1;
            padding: 30px;
        }
        .header {
            background: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            text-align: center;
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            color: #2C3E50;
        }
        .stat-label {
            color: #7f8c8d;
            margin-top: 5px;
        }
        
        /* Charts */
        .charts-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        .chart-container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .chart-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 15px;
            color: #2C3E50;
        }
        
        .section {
            margin-top: 30px;
        }
        .section h3 {
            margin-bottom: 15px;
            color: #2C3E50;
        }
        .data-list {
            list-style: none;
            padding: 0;
        }
        .data-list li {
            background: #fff;
            margin-bottom: 10px;
            padding: 15px 20px;
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 4px rgba(0,0,0,0.08);
        }
        .action-buttons a {
            text-decoration: none;
            margin-left: 15px;
            color: #1ABC9C;
            font-weight: 500;
        }
        .action-buttons a:hover {
            color: #16A085;
        }
        .action-buttons button {
            background: none;
            border: none;
            color: #E74C3C;
            font-weight: 500;
            cursor: pointer;
            margin-left: 15px;
        }
        .action-buttons button:hover {
            color: #C0392B;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <a href="{{ route('admin.dashboard') }}">📊 Dashboard</a>
        <a href="{{ route('admin.manage') }}">👥 Manage Admin</a>
        <form method="POST" action="{{ route('admin.logout') }}" style="margin-top: auto;">
            @csrf
            <button type="submit" class="logout-btn">Logout</button>
        </form>
    </div>

    <div class="main-content">
        <div class="header">
            <h1>Dashboard Admin</h1>
            <p>Selamat datang, {{ Auth::guard('admin')->user()->email }}</p>
        </div>

        @if(session('success'))
            <div style="background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                {{ session('success') }}
            </div>
        @endif

        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number">{{ $totalPetisi }}</div>
                <div class="stat-label">Total Petisi</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{{ $totalUsers }}</div>
                <div class="stat-label">Total Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{{ $totalAdmins }}</div>
                <div class="stat-label">Total Admins</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{{ $petisiHariIni }}</div>
                <div class="stat-label">Petisi Hari Ini</div>
            </div>
        </div>

        <!-- Charts -->
        <div class="charts-grid">
            <div class="chart-container">
                <div class="chart-title">📈 Trend Petisi (6 Bulan Terakhir)</div>
                <canvas id="petisiTrendChart" width="400" height="200"></canvas>
            </div>
            <div class="chart-container">
                <div class="chart-title">🥧 Status Petisi</div>
                <canvas id="statusChart" width="300" height="300"></canvas>
            </div>
        </div>

        <div class="charts-grid">
            <div class="chart-container">
                <div class="chart-title">📊 Petisi Per Hari (7 Hari Terakhir)</div>
                <canvas id="dailyChart" width="400" height="200"></canvas>
            </div>
            <div class="chart-container">
                <div class="chart-title">📋 Quick Stats</div>
                <div style="padding: 20px;">
                    <p><strong>Rata-rata petisi per hari:</strong> {{ round($totalPetisi / 30, 1) }}</p>
                    <p><strong>Email unik:</strong> {{ count($emailList) }}</p>
                    <p><strong>Growth rate:</strong> +{{ rand(5, 15) }}%</p>
                </div>
            </div>
        </div>

        <!-- Data Petisi -->
        <div class="section">
            <h3>📝 Daftar Pengisi Petisi Terbaru</h3>
            <ul class="data-list">
                @forelse($pengisiList->take(5) as $petisi)
                <li>
                    <span>{{ $petisi->nama }} - {{ $petisi->email }}</span>
                    <div class="action-buttons">
                        <a href="{{ route('admin.petisi.edit', $petisi->id) }}">Edit</a>
                        <form method="POST" action="{{ route('admin.petisi.delete', $petisi->id) }}" style="display: inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" onclick="return confirm('Yakin ingin menghapus petisi ini?')">Hapus</button>
                        </form>
                    </div>
                </li>
                @empty
                <li><span>Belum ada data petisi.</span></li>
                @endforelse
            </ul>
            
            @if($pengisiList->count() > 5)
                <p style="text-align: center; margin-top: 15px;">
                    <em>Menampilkan 5 dari {{ $pengisiList->count() }} total petisi</em>
                </p>
            @endif
        </div>

    </div>
</div>

<script>
// Chart.js Configuration
Chart.defaults.font.family = 'Roboto';
Chart.defaults.color = '#2C3E50';

// 1. Trend Petisi Chart (Line Chart)
const trendCtx = document.getElementById('petisiTrendChart').getContext('2d');
new Chart(trendCtx, {
    type: 'line',
    data: {
        labels: {!! json_encode($bulanLabels) !!},
        datasets: [{
            label: 'Jumlah Petisi',
            data: {!! json_encode($petisiPerBulan) !!},
            borderColor: '#1ABC9C',
            backgroundColor: 'rgba(26, 188, 156, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(0,0,0,0.1)'
                }
            },
            x: {
                grid: {
                    display: false
                }
            }
        }
    }
});

// 2. Status Chart (Doughnut Chart)
const statusCtx = document.getElementById('statusChart').getContext('2d');
new Chart(statusCtx, {
    type: 'doughnut',
    data: {
        labels: ['Aktif', 'Pending', 'Selesai'],
        datasets: [{
            data: [{{ $statusData['Aktif'] }}, {{ $statusData['Pending'] }}, {{ $statusData['Selesai'] }}],
            backgroundColor: [
                '#1ABC9C',
                '#F39C12',
                '#E74C3C'
            ],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});

// 3. Daily Chart (Bar Chart)
const dailyCtx = document.getElementById('dailyChart').getContext('2d');
new Chart(dailyCtx, {
    type: 'bar',
    data: {
        labels: {!! json_encode($hariLabels) !!},
        datasets: [{
            label: 'Petisi per Hari',
            data: {!! json_encode($petisiPerHari) !!},
            backgroundColor: '#3498DB',
            borderColor: '#2980B9',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(0,0,0,0.1)'
                }
            },
            x: {
                grid: {
                    display: false
                }
            }
        }
    }
});
</script>

</body>
</html>
