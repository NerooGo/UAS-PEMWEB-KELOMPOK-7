<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            color: #333;
        }
        .container {
            max-width: 1000px;
            margin: 40px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #2C3E50;
            margin-bottom: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #2C3E50;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .action-buttons a {
            text-decoration: none;
            color: #1ABC9C;
            font-weight: 500;
            margin-right: 10px;
        }
        .action-buttons a:hover {
            color: #16A085;
        }
        .action-buttons button {
            background: none;
            border: none;
            color: #E74C3C;
            font-weight: 500;
            cursor: pointer;
            margin-left: 10px;
        }
        .action-buttons button:hover {
            color: #C0392B;
        }
        .back-button {
            display: inline-block;
            background-color: #E74C3C;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
        }
        .back-button:hover {
            background-color: #C0392B;
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .add-admin-btn {
            background-color: #1ABC9C;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            margin-bottom: 20px;
            display: inline-block;
        }
        .add-admin-btn:hover {
            background-color: #16A085;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Kelola Admin</h2>

    @if(session('success'))
        <div class="success">{{ session('success') }}</div>
    @endif

    <a href="{{ route('admin.register') }}" class="add-admin-btn">Tambah Admin Baru</a>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Email</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse($adminList as $admin)
                <tr>
                    <td>{{ $admin->id }}</td>
                    <td>{{ $admin->email }}</td>
                    <td class="action-buttons">
                        @if($admin->id != Auth::guard('admin')->id())
                            <form method="POST" action="{{ route('admin.admin.delete', $admin->id) }}" style="display: inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" onclick="return confirm('Yakin ingin menghapus admin ini?');">Hapus</button>
                            </form>
                        @else
                            <span style="color: #7f8c8d; font-style: italic;">Admin Aktif</span>
                        @endif
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="3" style="text-align: center; color: #7f8c8d;">Tidak ada data admin</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    <a href="{{ route('admin.dashboard') }}" class="back-button">Kembali ke Dashboard</a>
</div>

</body>
</html>
