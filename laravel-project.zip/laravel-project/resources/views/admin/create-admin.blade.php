<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">

<div class="min-h-screen flex items-center justify-center">
    <div class="max-w-md w-full bg-white p-6 rounded-lg shadow">
        <h2 class="text-2xl font-bold mb-6 text-center">Create Admin Account</h2>
        
        <div id="result" class="mb-4"></div>
        
        <button onclick="createAdmin()" class="w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 transition duration-200">
            Create Default Admin
        </button>
        
        <div class="mt-4 text-center">
            <p class="text-sm text-gray-600">
                This will create admin with:<br>
                Email: rifqiadiyatma55@gmail.com<br>
                Password: 1234
            </p>
        </div>
        
        <div class="mt-6 text-center">
            <a href="/admin/login" class="text-blue-500 hover:underline">Go to Admin Login</a>
        </div>
    </div>
</div>

<script>
function createAdmin() {
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = '<div class="text-blue-600">Creating admin...</div>';
    
    fetch('/create-admin-api')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                resultDiv.innerHTML = `
                    <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
                        <strong>Success!</strong><br>
                        Admin created successfully!<br>
                        Email: ${data.credentials.email}<br>
                        Password: ${data.credentials.password}
                    </div>
                `;
                
                // Auto redirect after 3 seconds
                setTimeout(() => {
                    window.location.href = '/admin/login';
                }, 3000);
            } else {
                resultDiv.innerHTML = `
                    <div class="bg-red-100 text-red-700 p-3 rounded mb-4">
                        <strong>Error:</strong><br>
                        ${data.message}
                    </div>
                `;
            }
        })
        .catch(error => {
            resultDiv.innerHTML = `
                <div class="bg-red-100 text-red-700 p-3 rounded mb-4">
                    <strong>Error:</strong><br>
                    ${error.message}
                </div>
            `;
        });
}
</script>

</body>
</html>
