<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Petisi Mahasiswa')</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <!-- Header -->
    <header class="bg-red-600 text-white py-4 fixed w-full z-10 top-0 left-0">
        <div class="max-w-6xl mx-auto flex justify-between items-center px-4">
            <div class="text-lg font-semibold">
                <a href="{{ route('home') }}" class="text-white">Ayo Bersuara</a>
            </div>
            <div>
                @guest
                    <a href="{{ route('login') }}" class="text-white font-semibold py-2 px-4 rounded-full hover:bg-red-700">Login</a>
                    <a href="{{ route('register') }}" class="text-white font-semibold py-2 px-4 rounded-full hover:bg-red-700 ml-4">Daftar</a>
                @else
                    <span class="text-white font-semibold">Hello, {{ Auth::user()->nama }}</span>
                    <form method="POST" action="{{ route('logout') }}" class="inline ml-4">
                        @csrf
                        <button type="submit" class="text-white font-semibold py-2 px-4 rounded-full hover:bg-red-700">Logout</button>
                    </form>
                @endguest
            </div>
        </div>
    </header>

    <main class="mt-20">
        @yield('content')
    </main>

    <footer class="text-center py-6 text-sm text-gray-500 bg-white mt-10 border-t">
        &copy; 2025 Forum Ayo Bersuara. All rights reserved.
    </footer>
</body>
</html>
