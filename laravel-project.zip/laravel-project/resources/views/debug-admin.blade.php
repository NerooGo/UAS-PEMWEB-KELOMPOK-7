<!DOCTYPE html>
<html>
<head>
    <title>Debug Admin Links</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ccc; }
        .success { color: green; }
        .error { color: red; }
        button, a { margin: 5px; padding: 10px; }
    </style>
</head>
<body>
    <h1>Debug Admin Links</h1>
    
    <div class="test-section">
        <h3>Test 1: Route Information</h3>
        <p><strong>Current URL:</strong> {{ url()->current() }}</p>
        <p><strong>Base URL:</strong> {{ url('/') }}</p>
        <p><strong>Admin Login Route:</strong> 
            @try
                {{ route('admin.login') }}
                <span class="success">✓ Route exists</span>
            @catch(Exception $e)
                <span class="error">✗ Route not found: {{ $e->getMessage() }}</span>
            @endtry
        </p>
    </div>

    <div class="test-section">
        <h3>Test 2: Direct Links</h3>
        <a href="/admin/login" target="_blank">Direct Link: /admin/login</a><br>
        <a href="{{ url('/admin/login') }}" target="_blank">URL Helper: admin/login</a><br>
        <a href="http://127.0.0.1:8000/admin/login" target="_blank">Full URL</a><br>
    </div>

    <div class="test-section">
        <h3>Test 3: JavaScript Redirect</h3>
        <button onclick="testRedirect()">Test JS Redirect</button>
        <button onclick="testNewWindow()">Test New Window</button>
    </div>

    <div class="test-section">
        <h3>Test 4: Form Submit</h3>
        <form action="/admin/login" method="GET">
            <button type="submit">Form Submit to Admin</button>
        </form>
    </div>

    <div class="test-section">
        <h3>Test 5: Available Routes</h3>
        <a href="/test-routes" target="_blank">View All Admin Routes</a>
    </div>

    <script>
        function testRedirect() {
            console.log('Testing redirect...');
            window.location.href = '/admin/login';
        }

        function testNewWindow() {
            console.log('Testing new window...');
            window.open('/admin/login', '_blank');
        }

        // Log semua link clicks
        document.addEventListener('click', function(e) {
            if (e.target.tagName === 'A') {
                console.log('Link clicked:', e.target.href);
            }
        });
    </script>
</body>
</html>
