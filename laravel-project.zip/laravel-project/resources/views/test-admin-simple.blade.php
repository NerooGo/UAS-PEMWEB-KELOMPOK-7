<!DOCTYPE html>
<html>
<head>
    <title>Test Admin Links</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 50px; }
        .test-link { 
            display: block; 
            margin: 20px 0; 
            padding: 15px; 
            background: #f0f0f0; 
            text-decoration: none; 
            color: #333;
            border-radius: 5px;
        }
        .test-link:hover { background: #e0e0e0; }
        button { 
            padding: 15px; 
            margin: 10px 0; 
            font-size: 16px; 
            cursor: pointer;
            display: block;
            width: 200px;
        }
    </style>
</head>
<body>
    <h1>Test Admin Links</h1>
    
    <h3>Method 1: Direct Links</h3>
    <a href="/admin/login" class="test-link">Direct Link: /admin/login</a>
    <a href="http://127.0.0.1:8000/admin/login" class="test-link">Full URL Link</a>
    
    <h3>Method 2: JavaScript Buttons</h3>
    <button onclick="window.location.href='/admin/login'">JS Redirect</button>
    <button onclick="window.open('/admin/login', '_blank')">JS New Tab</button>
    
    <h3>Method 3: Form Submit</h3>
    <form action="/admin/login" method="GET">
        <button type="submit">Form Submit</button>
    </form>
    
    <h3>Method 4: Meta Refresh (Auto redirect in 5 seconds)</h3>
    <button onclick="testMetaRefresh()">Test Meta Refresh</button>
    
    <script>
        function testMetaRefresh() {
            document.head.innerHTML += '<meta http-equiv="refresh" content="2;url=/admin/login">';
            alert('Will redirect in 2 seconds...');
        }
        
        console.log('Test page loaded');
        console.log('Current URL:', window.location.href);
    </script>
</body>
</html>
