<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Petisi Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">

<!-- Header - SAMA PERSIS dengan asli -->
<header class="bg-red-600 text-white py-4 fixed w-full z-10 top-0 left-0">
    <div class="max-w-6xl mx-auto flex justify-between items-center px-4">
        <div class="text-lg font-semibold">
            <a href="{{ route('home') }}" class="text-white">Ayo Bersuara</a>
        </div>
        <div>
            @if (!$isLoggedIn)
                <a href="{{ route('login') }}" class="text-white font-semibold py-2 px-4 rounded-full hover:bg-red-700">Login</a>
                <a href="{{ route('register') }}" class="text-white font-semibold py-2 px-4 rounded-full hover:bg-red-700 ml-4">Daftar</a>
            @else
                <span class="text-white font-semibold">Hello, {{ Auth::user()->nama }}</span>
                <form method="POST" action="{{ route('logout') }}" class="inline ml-4">
                    @csrf
                    <button type="submit" class="text-white font-semibold py-2 px-4 rounded-full hover:bg-red-700">Logout</button>
                </form>
            @endif
        </div>
    </div>
</header>

<!-- Hero Section -->
<section class="bg-red-600 text-white py-20 text-center mt-20">
    <div class="max-w-4xl mx-auto px-4">
        <h1 class="text-4xl md:text-5xl font-bold mb-6">"Satu suara mahasiswa mungkin terdengar kecil. Tapi ribuan suara dapat mengguncang sistem."</h1>
        <p class="text-xl mb-6">Gabung dalam gerakan kolektif yang memperjuangkan keadilan, transparansi, dan perubahan kebijakan demi masa depan bangsa.</p>
        <a href="#form" class="bg-white text-red-600 font-semibold py-2 px-6 rounded-full hover:bg-gray-200 transition">Tandatangani Petisi</a>
    </div>
</section>

<!-- Tentang Petisi -->
<section class="py-16 bg-gray-50 px-6">
    <div class="max-w-3xl mx-auto text-center">
        <h2 class="text-3xl font-bold mb-6">Mengapa Petisi Ini Penting?</h2>
        <p class="text-lg mb-4">Petisi ini adalah suara kita bersama. Ketika mahasiswa bersatu, kita bisa menjadi kekuatan yang mampu mendorong perubahan. Kami menuntut keadilan, perlindungan terhadap korban, dan tindakan nyata dari lembaga kampus terhadap segala bentuk kekerasan dan ketidakadilan.</p>
        <p class="text-lg">Dengan menandatangani, kamu bukan hanya memberikan dukungan—kamu menjadi bagian dari gerakan perubahan yang lebih besar.</p>
    </div>
</section>

<!-- Berita Terkini -->
<section class="py-16 px-6 bg-white">
    <div class="max-w-6xl mx-auto">
        <h2 class="text-3xl font-bold text-center mb-10">Berita Terkini</h2>
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!-- Berita 1 -->
            <div class="bg-gray-100 rounded shadow hover:shadow-lg p-5">
                <p class="text-sm text-gray-500 mb-2">14 April 2025</p>
                <h3 class="font-bold mb-2">Mahasiswa Suarakan Aksi Kolektif Tangani Kekerasan</h3>
                <p class="text-sm text-gray-700">Aksi solidaritas mahasiswa UIN Malang menuntut tindakan tegas atas dugaan kekerasan yang terjadi di lingkungan kampus...</p>
                <a href="#" class="text-red-600 text-sm font-semibold hover:text-red-700 mt-2 inline-block">Baca selengkapnya →</a>
            </div>
            <!-- Berita 2 -->
            <div class="bg-gray-100 rounded shadow hover:shadow-lg p-5">
                <p class="text-sm text-gray-500 mb-2">12 Maret 2024</p>
                <h3 class="font-bold mb-2">Kolaborasi Kampus Lawan Radikalisme</h3>
                <p class="text-sm text-gray-700">Perguruan tinggi Indonesia membentuk koalisi nasional untuk mencegah radikalisme dan menciptakan lingkungan akademik yang sehat...</p>
                <a href="#" class="text-red-600 text-sm font-semibold hover:text-red-700 mt-2 inline-block">Baca selengkapnya →</a>
            </div>
            <!-- Berita 3 -->
            <div class="bg-gray-100 rounded shadow hover:shadow-lg p-5">
                <p class="text-sm text-gray-500 mb-2">10 Maret 2024</p>
                <h3 class="font-bold mb-2">Peran Keluarga Dalam Cegah Ekstremisme di Kampus</h3>
                <p class="text-sm text-gray-700">Forum nasional orang tua mahasiswa membahas pentingnya komunikasi dan dukungan moral dari rumah...</p>
                <a href="#" class="text-red-600 text-sm font-semibold hover:text-red-700 mt-2 inline-block">Baca selengkapnya →</a>
            </div>
        </div>
    </div>
</section>

<!-- Form Petisi -->
<section id="form" class="bg-gray-50 py-16 px-6">
    <div class="max-w-2xl mx-auto">
        <h2 class="text-2xl font-bold mb-6 text-center">Tandatangani Petisi Ini</h2>

        @if (session('error'))
            <div class="bg-yellow-100 text-yellow-800 p-4 rounded mb-6 text-center">
                {{ session('error') }}
            </div>
        @endif

        @if (session('success'))
            <div class="bg-green-100 text-green-800 p-4 rounded mb-6 text-center">
                {{ session('success') }}
            </div>
        @endif

        @if ($isLoggedIn)
            <form method="post" action="{{ route('petisi.store') }}" class="space-y-4">
                @csrf
                <input type="text" name="nama" placeholder="Nama Lengkap" class="w-full px-4 py-2 border rounded" required>
                <input type="email" name="email" placeholder="Email Aktif" class="w-full px-4 py-2 border rounded" required>
                <textarea name="pesan" placeholder="Pesan Dukungan (opsional)" rows="4" class="w-full px-4 py-2 border rounded"></textarea>
                <div class="flex justify-between">
                    <button type="submit" class="bg-red-600 text-white px-6 py-2 rounded hover:bg-red-700 transition w-1/2 mr-2">Kirim Dukungan</button>
                    <a href="{{ route('review') }}" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition w-1/2 ml-2 text-center">Review Petisi</a>
                </div>
            </form>
        @else
            <div class="text-center mb-6">
                <a href="{{ route('login') }}" class="text-red-600 font-semibold">Login atau Daftar untuk memberi dukungan</a>
            </div>
        @endif
    </div>
</section>

<footer class="text-center py-6 text-sm text-gray-500 bg-white mt-10 border-t">
    &copy; 2025 Forum Ayo Bersuara. All rights reserved.
</footer>

</body>
</html>
