<?php

namespace App\Http\Controllers;

use App\Models\Pengisi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PetisiController extends Controller
{
    public function index()
    {
        // Cek apakah user sudah login
        $isLoggedIn = Auth::check();
        
        return view('index', compact('isLoggedIn'));
    }

    public function store(Request $request)
    {
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'Silakan login terlebih dahulu');
        }

        $request->validate([
            'nama' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'pesan' => 'nullable|string',
        ]);

        Pengisi::create([
            'nama' => $request->nama,
            'email' => $request->email,
            'pesan' => $request->pesan,
        ]);

        return redirect()->back()->with('success', 'Dukungan berhasil dikirim!');
    }

    public function review()
    {
        $pengisiList = Pengisi::all()->map(function ($pengisi) {
            // Sensor nama dan email
            $pengisi->nama = substr($pengisi->nama, 0, 1) . str_repeat('*', strlen($pengisi->nama) - 1);
            
            $emailParts = explode('@', $pengisi->email);
            if (count($emailParts) > 1) {
                $emailParts[0] = substr($emailParts[0], 0, 2) . str_repeat('*', max(0, strlen($emailParts[0]) - 2));
                $pengisi->email = implode('@', $emailParts);
            }
            
            return $pengisi;
        });

        return view('review', compact('pengisiList'));
    }
}
