<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pengisi extends Model
{
    use HasFactory;

    protected $table = 'pengisi'; // Menggunakan tabel pengisi yang sudah ada

    protected $fillable = [
        'nama',
        'email',
        'pesan',
    ];

    // DISABLE timestamps karena tabel lama tidak punya created_at, updated_at
    public $timestamps = false;
}
