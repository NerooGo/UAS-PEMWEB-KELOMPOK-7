<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Daftar Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
    <div class="bg-white p-8 rounded shadow-md w-full max-w-md">
        <h2 class="text-2xl font-bold mb-4 text-center">Daftar Admin</h2>

        <?php if($errors->any()): ?>
            <div class="bg-red-100 text-red-700 px-4 py-2 rounded mb-4">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('admin.register')); ?>">
            <?php echo csrf_field(); ?>
            <input type="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" class="w-full p-2 mb-4 border rounded" required>
            <input type="password" name="password" placeholder="Password" class="w-full p-2 mb-4 border rounded" required>
            <input type="password" name="password_confirmation" placeholder="Konfirmasi Password" class="w-full p-2 mb-4 border rounded" required>
            <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Daftar</button>
        </form>

        <div class="text-center mt-4 text-sm">
            Sudah punya akun? <a href="<?php echo e(route('admin.login')); ?>" class="text-blue-600 hover:underline">Login di sini</a>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-project\resources\views/admin/auth/register.blade.php ENDPATH**/ ?>