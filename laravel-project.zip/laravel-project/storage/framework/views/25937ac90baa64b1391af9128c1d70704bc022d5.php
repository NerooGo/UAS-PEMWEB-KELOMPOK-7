<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Petisi</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">

<!-- Header -->
<header class="bg-gradient-to-r from-red-500 to-red-600 text-white py-4 fixed w-full z-10 top-0 left-0">
    <div class="max-w-6xl mx-auto flex justify-between items-center px-6">
        <div class="text-lg font-semibold">
            <a href="<?php echo e(route('home')); ?>" class="text-white">Petisi Mahasiswa</a>
        </div>
        <div>
            <a href="<?php echo e(route('home')); ?>" class="bg-white text-red-600 font-semibold py-2 px-4 rounded-full hover:bg-gray-200">Kembali ke Index</a>
        </div>
    </div>
</header>

<!-- Review Section -->
<section class="py-16 px-6 bg-white mt-20">
  <div class="max-w-6xl mx-auto">
    <h2 class="text-4xl font-bold text-center text-gray-900 mb-10">Review Petisi</h2>

    <?php if($pengisiList->isEmpty()): ?>
      <div class="bg-yellow-100 text-yellow-800 p-4 rounded mb-6 text-center">
        Tidak ada data petisi.
      </div>
    <?php endif; ?>

    <!-- Tabel Review Pengisi Petisi -->
    <div class="overflow-x-auto shadow-lg rounded-lg">
      <table class="min-w-full table-auto">
        <thead class="bg-red-600 text-white">
            <tr>
                <th class="py-3 px-6 text-left">Nama</th>
                <th class="py-3 px-6 text-left">Email</th>
                <th class="py-3 px-6 text-left">Pesan Dukungan</th>
            </tr>
        </thead>
        <tbody class="text-gray-700">
            <?php $__currentLoopData = $pengisiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50">
                    <td class="py-3 px-6 border-t"><?php echo e($review->nama); ?></td>
                    <td class="py-3 px-6 border-t"><?php echo e($review->email); ?></td>
                    <td class="py-3 px-6 border-t"><?php echo e($review->pesan ?? '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</section>

<footer class="text-center py-6 text-sm text-gray-500 bg-white mt-10 border-t">
  &copy; 2025 Forum Petisi Mahasiswa. All rights reserved.
</footer>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-project\resources\views/review.blade.php ENDPATH**/ ?>