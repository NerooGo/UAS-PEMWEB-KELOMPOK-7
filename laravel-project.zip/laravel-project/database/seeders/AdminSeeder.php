<?php

namespace Database\Seeders;

use App\Models\Admin;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    public function run()
    {
        // Hapus admin lama jika ada
        Admin::where('email', 'rifqiadiyatma55@gmail.com')->delete();
        
        // Buat admin baru
        Admin::create([
            'email' => 'rifqiadiyatma55@gmail.com',
            'password' => Hash::make('1234'),
        ]);

        // Admin tambahan untuk testing
        Admin::updateOrCreate(
            ['email' => 'admin@test.com'],
            ['password' => Hash::make('password')]
        );

        echo "Admin berhasil dibuat!\n";
        echo "Email: rifqiadiyatma55@gmail.com\n";
        echo "Password: 1234\n";
    }
}
