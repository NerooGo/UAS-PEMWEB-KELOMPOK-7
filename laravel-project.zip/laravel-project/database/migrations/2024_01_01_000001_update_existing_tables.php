<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        // Update tabel users jika perlu menambah kolom
        if (Schema::hasTable('users')) {
            Schema::table('users', function (Blueprint $table) {
                // Tambahkan kolom jika belum ada
                if (!Schema::hasColumn('users', 'email_verified_at')) {
                    $table->timestamp('email_verified_at')->nullable();
                }
                if (!Schema::hasColumn('users', 'remember_token')) {
                    $table->rememberToken();
                }
                if (!Schema::hasColumn('users', 'created_at')) {
                    $table->timestamps();
                }
            });
        }

        // Update tabel admin jika perlu
        if (Schema::hasTable('admin')) {
            Schema::table('admin', function (Blueprint $table) {
                if (!Schema::hasColumn('admin', 'created_at')) {
                    $table->timestamps();
                }
            });
        }

        // Update tabel pengisi jika perlu
        if (Schema::hasTable('pengisi')) {
            Schema::table('pengisi', function (Blueprint $table) {
                if (!Schema::hasColumn('pengisi', 'created_at')) {
                    $table->timestamps();
                }
            });
        }
    }

    public function down()
    {
        // Rollback jika diperlukan
        if (Schema::hasTable('users')) {
            Schema::table('users', function (Blueprint $table) {
                $table->dropColumn(['email_verified_at', 'remember_token']);
                if (Schema::hasColumn('users', 'created_at')) {
                    $table->dropTimestamps();
                }
            });
        }
    }
};
