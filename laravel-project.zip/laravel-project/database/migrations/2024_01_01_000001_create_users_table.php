<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        // Tambahkan timestamps ke tabel users jika belum ada
        if (!Schema::hasColumn('users', 'created_at')) {
            Schema::table('users', function (Blueprint $table) {
                $table->timestamps();
            });
        }

        // Tambahkan timestamps ke tabel admin jika belum ada
        if (!Schema::hasColumn('admin', 'created_at')) {
            Schema::table('admin', function (Blueprint $table) {
                $table->timestamps();
            });
        }

        // Tambahkan timestamps ke tabel pengisi jika belum ada
        if (!Schema::hasColumn('pengisi', 'created_at')) {
            Schema::table('pengisi', function (Blueprint $table) {
                $table->timestamps();
            });
        }

        // Tambahkan remember_token ke users jika belum ada
        if (!Schema::hasColumn('users', 'remember_token')) {
            Schema::table('users', function (Blueprint $table) {
                $table->rememberToken();
            });
        }
    }

    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['created_at', 'updated_at', 'remember_token']);
        });

        Schema::table('admin', function (Blueprint $table) {
            $table->dropColumn(['created_at', 'updated_at']);
        });

        Schema::table('pengisi', function (Blueprint $table) {
            $table->dropColumn(['created_at', 'updated_at']);
        });
    }
};
